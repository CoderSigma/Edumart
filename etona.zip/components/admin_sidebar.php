
<div class="sidebar" id="sidebar">
    <div class="toggle-btn" onclick="toggleSidebar()">&#9776;</div>
    <h3>Admin Dashboard</h3>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a>
    <a href="manage_users.php"><i class="fas fa-users"></i> <span>Manage Users</span></a>
    <a href="item_listing.php"><i class="fas fa-box"></i> <span>Item Listings</span></a>
    <a href="reports.php"><i class="fas fa-chart-bar"></i> <span>Reports</span></a>
    <a href="messages.php"><i class="fas fa-envelope"></i> <span>Messages</span></a>
    <a href="manage_categories.php"><i class="bi bi-tags"></i> <span>Manage Categories</span></a>
    <a href="announcement.php"><i class="bi bi-flag"></i> <span>Announcement</span></a> <!-- New Link -->
</div>